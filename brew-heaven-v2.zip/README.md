# Brew Haven V2

Replace these files in your existing GitHub project.

- lib/mockData.ts
- components/Hero.tsx

This upgrades menu images and hero image with real cafe photography.
