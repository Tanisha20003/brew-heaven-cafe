export default function Hero(){
 return (
  <section style={{height:'70vh',backgroundImage:"url('https://images.pexels.com/photos/302899/pexels-photo-302899.jpeg')",backgroundSize:'cover',display:'flex',alignItems:'center',justifyContent:'center',color:'white'}}>
    <div><h1>Brew Haven Cafe</h1><p>Premium Coffee • Momos • Desserts</p></div>
  </section>
 )
}
