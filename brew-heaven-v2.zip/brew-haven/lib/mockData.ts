// Brew Haven V2 image fixes
export const menuItems = [
 {name:"Espresso", image:"https://images.pexels.com/photos/312418/pexels-photo-312418.jpeg"},
 {name:"Cappuccino", image:"https://images.pexels.com/photos/302899/pexels-photo-302899.jpeg"},
 {name:"Latte", image:"https://images.pexels.com/photos/3407880/pexels-photo-3407880.jpeg"},
 {name:"Veg Momos", image:"https://images.pexels.com/photos/5409010/pexels-photo-5409010.jpeg"},
 {name:"Paneer Momos", image:"https://images.pexels.com/photos/5378940/pexels-photo-5378940.jpeg"},
 {name:"Chicken Momos", image:"https://images.pexels.com/photos/4449068/pexels-photo-4449068.jpeg"},
 {name:"Burger", image:"https://images.pexels.com/photos/1639557/pexels-photo-1639557.jpeg"},
 {name:"Pizza", image:"https://images.pexels.com/photos/825661/pexels-photo-825661.jpeg"},
 {name:"Cheesecake", image:"https://images.pexels.com/photos/1126359/pexels-photo-1126359.jpeg"},
 {name:"Brownie", image:"https://images.pexels.com/photos/291528/pexels-photo-291528.jpeg"}
];
